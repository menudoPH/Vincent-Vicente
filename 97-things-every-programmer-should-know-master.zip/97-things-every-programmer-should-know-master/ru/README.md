97 вещей, которые должен знать каждый программист
======

*Жемчужины мудрости для программистов, собранные ведущими специалистами-практиками.*


Это перевод [проекта '97 вещей, которые должен знать каждый программист'](http://programmer.97things.oreilly.com/wiki/index.php/97_Things_Every_Programmer_Should_Know).

Весь текст находится под лицензией [Creative Commons Attribution Non Commercial Share Alike 3.0 license](http://creativecommons.org/licenses/by-nc-sa/3.0/).

Если вы обнаружили ошибки или у вас есть какие-либо предложения, вы можете создать [issue](https://github.com/97-things/97-things-every-programmer-should-know/issues) или сделать [pull request](https://github.com/97-things/97-things-every-programmer-should-know/pulls) в [репозиторий](https://github.com/97-things/97-things-every-programmer-should-know).

Переведено пользователем ЖЖ под ником [avl](http://avl.livejournal.com/profile).
Оригинал перевода можно найти [здесь](http://avl.livejournal.com/89477.html).