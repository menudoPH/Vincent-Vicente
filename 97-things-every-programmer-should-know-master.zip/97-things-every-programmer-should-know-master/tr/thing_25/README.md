# Test Verilerinizle Sevimli Olmayın

> *Geç oluyordu. Üzerinde çalıştığım sayfa düzenini test etmek için bazı yer tutucu verileri gönderiyordum.*

> *Kullanıcıların isimlerini The Clash üyelerine tahsis ettim. Şirket isimleri? Sex Pistols'un şarkı isimleri de işe yarardı. Şimdi birkaç hisse senedi sembolüne ihtiyacım vardı, sadece büyük harflerle birkaç harfli kelime.*

> ***bu** birkaç harfli kelimeleri kullandım.*

> *Zararsız görünüyordu. Gerçek veri kaynağını bağlamadan önceki gün kendimi ve belki diğer geliştiricileri eğlendirecek bir şey.*

> *Ertesi sabah, bir proje yöneticisi sunum için bazı ekran görüntüleri aldı.**

Programlama tarihi bu tür savaş hikayeleriyle dolu. Geliştiricilerin ve tasarımcıların "kimsenin göremeyeceği" şeyler beklenmedik bir şekilde görünür hale geldi. Sızıntı türü değişebilir, ancak gerçekleştiğinde sorumlu kişi, ekip veya şirket için ölümcül olabilir. Örnekler şunları içerir:

- Bir durum toplantısı sırasında, müşteri henüz uygulanmamış bir düğmeye tıklar. Onlara "Bir daha tıklama, seni moron" deniyor.
- Eski bir sistemi koruyan bir yazılımcıya bir hata iletişim kutusu eklemesi söylendi ve onu güçlendirmek için mevcut sahne arkası günlük kaydının çıktısını kullanmaya karar verdi. Kullanıcılar birdenbire "Kutsal veritabanı işleme hatası Batman!" gibi mesajlarla karşı karşıya kalıyor herhangi bir hata alındığında.
- Birisi test ve canlı yönetim arayüzlerini karıştırıyor ve bazı "komik" veri girişleri yapıyor. Müşteriler, çevrimiçi mağazanızda 1 milyon dolarlık "Bill Gates şeklindeki kişisel masaj aletini" indirimde görüyor.

"Gerçek ayakkabılarını giyerken, yalan dünyanın yarısını dolaşır" şeklindeki eski deyişi benimsemek için, Bu çağda, geliştiricinin saat dilimindeki herhangi biri bu konuda bir şey yapmak için uyanık olmadan önce Dugg, Twittered ve Flibflarbed olabilir.

Kaynak kodunuz bile mutlaka incelemeden muaf değildir. 2004'te, Windows 2000 kaynak kodunun bir tarball'ı dosya paylaşım ağlarına girdiğinde, bazı insanlar neşeyle küfür, hakaret ve [diğer komik içerik](http://www.kuro5hin.org/story/2004/2/15/71552/7795) için bu dosyaya girdiler. (`// KORKUNÇ KORKUNÇ YOK İYİ ÇOK KÖTÜ HACK` yorumu, kabul ediyorum, o zamandan beri zaman zaman benim tarafımdan benimsendi!)

Özetle, kodunuza herhangi bir metin yazarken (yorumlar, günlük kaydı, diyaloglar veya test verileri) her zaman kendinize, genel hale gelirse nasıl görüneceğini sorun. Her yönden bazı kırmızı yüzleri kurtaracak.

[Rod Begbie](http://programmer.97things.oreilly.com/wiki/index.php/Rod_Begbie) Tarafından