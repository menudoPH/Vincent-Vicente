Her Yazılımcının Bilmesi Gereken 97 Şey
======

*Önde gelen uygulayıcılardan toplanan yazılımcılar için bilgelik incileri.*

Bu [GitBook](https://www.gitbook.io) ['Her Yazılımcının Bilmesi Gereken 97 Şey' projesinin versiyondur](http://programmer.97things.oreilly.com/wiki/index.php/97_Things_Every_Programmer_Should_Know).

Tüm içerik [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 lisansı](http://creativecommons.org/licenses/by-nc-sa/3.0/) kapsamında lisanslanmıştır. Kitabın basılı sürümleri [Amazon.com](http://www.amazon.com/Things-Every-Programmer-Should-Know/dp/0596809484) adresinde mevcuttur.

Herhangi bir hata bulursanız veya herhangi bir öneriniz varsa, bir [konu oluşturabilir](https://github.com/97-things/97-things-every-programmer-should-know/issues) veya [depoya](https://github.com/97-things/97-things-every-programmer-should-know) bir [çekme isteği](https://github.com/97-things/97-things-every-programmer-should-know/pulls) gönderebilirsiniz.