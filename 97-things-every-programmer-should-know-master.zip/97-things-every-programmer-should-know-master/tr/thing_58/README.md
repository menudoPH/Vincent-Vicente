# Geleceğe Mesaj

Belki de çoğu zeki insanlar olduğu içindir, ancak programcılarla yan yana ders verdiğim ve çalıştığım tüm yıllar boyunca, görünüşe göre çoğu, mücadele ettikleri problemler zor olduğu için çözümlerin olması gerektiğini düşündüler, herkesin (kod yazıldıktan birkaç ay sonra bile) anlaması ve sürdürmesi aynı derecede zor olabilir.

Veri yapıları sınıfımdaki bir öğrenci olan ve bana ne yazdığını göstermek için içeri girmek zorunda kalan Joe ile ilgili bir olayı hatırlıyorum. "Betcha ne yaptığını tahmin edemez!" diye öttü.

"Haklısın," diye kabul ettim örneğine çok fazla zaman harcamadan ve önemli bir mesajı nasıl ileteceğimi merak etmeden. "Eminim bunun üzerinde çok çalışıyorsun. Acaba önemli bir şeyi unutmadıysan merak ediyorum. Söylesene Joe, senin küçük bir erkek kardeşin yok mu?"

"Evet. Elbette! Phil! O sizin Giriş sınıfınızda. O da programlama öğreniyor!" Joe gururla duyurdu.

"Bu harika," diye yanıtladım. "Acaba bu kodu okuyabiliyor mu?"

"Mümkün değil!" dedi Joe. "Bu zor bir şey!"

"Diyelim ki, bunun gerçek çalışma kodu olduğunu ve birkaç yıl içinde Phil'in bir bakım güncellemesi yapması için tutulduğunu. Onun için ne yaptınız?" diye önerdim. Joe gözlerini kırpıştırarak bana baktı. "Phil'in gerçekten zeki olduğunu biliyoruz, değil mi?" Joe başını salladı. "Bunu söylemekten nefret ediyorum ama ben de oldukça zekiyim!" Joe gülümsedi. "Yani, burada ne yaptığınızı kolayca anlayamazsam ve çok zeki küçük kardeşiniz muhtemelen bunun üzerine kafa yorarsa, bu yazdıklarınız ne anlama geliyor?" Joe koduna bana göründüğünden biraz farklı baktı. "Buna ne dersin, Ben senin arkadaş canlısı akıl hocanım" dedim en iyi sesimle, "Yazdığın her kod satırını gelecekte biri için bir mesaj olarak düşün senin küçük kardeşin olabilecek biri. Bu akıllı kişiye bu zor problemin nasıl çözüleceğini yeniden açıklıyoruz.

"Hayal etmek istediğiniz bu mu? Gelecekteki akıllı programcının kodunuzu görüp 'Vay! Bu harika! Burada ne yapıldığını çok iyi anlayabiliyorum ve ne kadar zarif bir şey olduğuna hayret ediyorum - hayır, bekle - bu ne güzel bir kod parçası. Ekibimdeki diğer insanlara göstereceğim. Bu bir başyapıt!'

"Joe, bu zor sorunu çözen ama şarkı söyleyecek kadar güzel olacak bir kod yazabileceğini mi sanıyorsun? Evet, tıpkı akıldan çıkmayan bir melodi gibi. Sanırım senin çok zor çözümünü bulabilen herkes burada da yazabilir. güzel bir şey yaz. Hmm... Acaba güzellik üzerine derecelendirmeye başlamalı mıyım? Ne düşünüyorsun, Joe?"

Joe işini aldı ve bana baktı, yüzünde küçük bir gülümseme belirdi. "Anladım, prof, dünyayı Phil için daha iyi hale getirmeye gidiyorum. Teşekkürler."

[Linda Rising](http://programmer.97things.oreilly.com/wiki/index.php/Linda_Rising) Tarafından